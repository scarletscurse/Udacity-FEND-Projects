

const Board = {
    width : 505,
    height : 606,
    numRows : 6,
    numCols : 5,
    dx : 101,
    dy : 83,
    playerStartPosition: {
        x : 202,
        y : 404,
    },
    Boundary : { // inclusive values
        left : 0,
        right : 404,
        up : 404-83*5,
        down : 404,
 },
}



// Enemies our player must avoid
var Enemy = function (y, speed) {
    // Variables applied to each of our instances go here,
    // we've provided one for you to get started
    
    // The image/sprite for our enemies, this uses
    // a helper we've provided to easily load images
    this.sprite = 'images/enemy-bug.png';
    this.x = 0;
    this.y = y;
    this.speed = speed;
    this.halfWidth = 45;
}

// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {
    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.

  

    if (this.x > Board.Boundary.right) {
        this.x = Board.Boundary.left;
    } else {
        this.x += this.speed * dt;
        
        // collision detection
         if (this.y === player.getY()) {
                if (Math.abs(this.x - player.getX()) < (this.halfWidth + player.getHalfWidth())) {
                    player.resetPlayer();
                }
            }
    }
};



// Draw the enemy on the screen, required method for game

Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};



// Now write your own player class
// This class requires an update(), render() and
// a handleInput() method.
class Player {
     constructor() {
    this.sprite = 'images/char-boy.png';
    this.nowPosition = Board.playerStartPosition;
    this.pressedKey = null;
    this.halfWidth = 30;
    this.left =Board.Boundary.left;
    this.up =Board.Boundary.up;
    this.down =Board.Boundary.down;
    this.right =Board.Boundary.right;
}

getX() {
    return this.nowPosition.x;
} 

getY() {
    return this.nowPosition.y;
}

resetPlayer() {
    this.nowPosition.x = 202;
    this.nowPosition.y = 404;
    this.render();

}

getHalfWidth() {
    return this.halfWidth;
}

update() {
    if (this.nowPosition.y === 404-83*5) {
        window.alert( "You've won. click ok to play again!")
        this.resetPlayer();
    }

     // move left if player is not in the left boundary
     if ((this.pressedKey === "left") && (this.nowPosition.x !== this.left) ) {
         this.nowPosition.x -=Board.dx;
     } 
    
     // move up if player is not in the upper boundary
     if ((this.pressedKey === "up") && (this.nowPosition.y !== this.up)) {
         this.nowPosition.y -=Board.dy;
     }
    
     // move right if player is not in the right boundary
     if ( (this.pressedKey === "right") && (this.nowPosition.x !== this.right)) {
         this.nowPosition.x +=Board.dx;
     }
    
     // move down if player is not in the down boundary
     if ((this.pressedKey === "down") && (this.nowPosition.y !==this.down)) {
         this.nowPosition.y +=Board.dy;
    
    }

  this.pressedKey = null;
   } 
render() {

 ctx.drawImage(Resources.get(this.sprite), this.nowPosition.x, this.nowPosition.y);
}
 handleInput(keyInput) {
        this.pressedKey = keyInput;
    }
}
 

// Now instantiate your objects.
// Place all enemy objects in an array called allEnemies
// Place the player object in a variable called player
let allEnemies = [new Enemy(404-83*1, 90), new Enemy(404-83*2, 150), new Enemy(404-83*3, 100), new Enemy(404-83*4, 120)];
let player = new Player();



// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});
