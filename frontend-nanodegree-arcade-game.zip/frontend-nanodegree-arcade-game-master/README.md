# Classic Arcade Game Project




frontend-nanodegree-arcade-game
===============================

An arcade game based on   [rubric](https://review.udacity.com/#!/projects/2696458597/rubric) for the udacity front-end Nanodegree. 




to-start-game
===============================
 To start the game just run the index.html file. there's nothing to install.
 
 
 frontend-nanodegree-arcade-game
===============================