# Project Title

A project for the udacity-fend-Nanodegree

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

None......  Since the game works offline by it's default structure...

```

### Installing

clone the directory to run the game.
it works offline too.
```
 i think i should rename this section to running.. (shrug)
 
to run the Game open the index.html file.






## Built With
* [Bootstrap](https://getbootstrap.com) - Used to generate RSS Feeds
* and the udacity Memory Game starter code[udacity](https://github.com/udacity/fend-project-memory-game)


## Contributing

Please read [Udacity FEND-Project Memory Game ](https://github.com/udacity/fend-project-memory-game) for details on our code of conduct, and the process for submitting pull requests to us.


## Authors

* **Udacity** - *Initial work* - [Udacity-fend-project-memory-game](https://github.com/udacity/fend-project-memory-game)
* **me**   -  

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details

## Acknowledgments

thanks to everyone whose code i used for inspiration 
*Bootstrap
*udacity